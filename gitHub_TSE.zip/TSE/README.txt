"""
/***************************************************************************
 *   Genetic coefficients optimisation program                             *
 *   Time-Series based Calibrator (TSE)                                    *
 *   Genetics optimisation program for DSSAT Crop Growth Models            *
 *                                -------------------                      *
 *          begin                : 2018-08-09                              *
 *                                                                         *
 *          copyright            : (C) 2018 by emir memic                  *
 *          email                : emir.memic@uni-hohenheim.de             *
 *          email                : emir_memic@windowslive.com	           *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *   These files are provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING*
 *   THE WARRANTY OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR  *
 *   PURPOSE.                                                              *
 ***************************************************************************/

 /*********************************************************************************
 * Copyright (c) 2010-2020, PyInstaller Development Team                          *
 * Copyright (c) 2005-2009, Giovanni Bajo                                         *
 * Based on previous work under copyright (c) 2002 McMillan Enterprises, Inc.     *
 *                                                                                *
 *                                                                                *
 * PyInstaller is licensed under the terms of the GNU General Public License      *
 * as published by the Free Software Foundation; either version 2 of the License, *
 * or (at your option) any later version.                                         *
***********************************************************************************/
 
/***********************************************************************************
 * Copyright (C) 2015 The Qt Company Ltd.                                          *
 * Copyright (C) 2005 Bjoern Bergstroem                                            *
 *                                                                                 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, modify, market, reproduce, grant sublicenses and distribute subject     *
 * to the following conditions: The above copyright notice and this permission     *
 * notice shall be included in all copies or substantial portions of the Software. *
 * These files are provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE      *
 * WARRANTY OF DESIGN, MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.       *
 * ********************************************************************************/ 
"""